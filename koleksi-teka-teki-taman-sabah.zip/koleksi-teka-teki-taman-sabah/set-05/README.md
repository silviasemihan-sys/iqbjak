# Set 05

20 soalan teka-teki tentang Taman-Taman Sabah.

Fail utama: `soalan.json`.
