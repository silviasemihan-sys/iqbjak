# Set 50

20 soalan teka-teki tentang Taman-Taman Sabah.

Fail utama: `soalan.json`.
